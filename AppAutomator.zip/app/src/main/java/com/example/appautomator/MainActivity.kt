package com.example.appautomator

import android.content.Intent
import android.provider.Settings
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var scriptInput: EditText
    private lateinit var logText: TextView
    private var job: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        scriptInput = findViewById(R.id.scriptInput)
        logText = findViewById(R.id.logText)

        val prefs = getSharedPreferences(AutomationService.PREFS, MODE_PRIVATE)
        val autoClose = findViewById<androidx.appcompat.widget.SwitchCompat>(R.id.autoCloseSwitch)
        autoClose.isChecked = prefs.getBoolean(AutomationService.KEY_AUTO_CLOSE, false)
        autoClose.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(AutomationService.KEY_AUTO_CLOSE, checked).apply()
        }

        findViewById<Button>(R.id.enableButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.pickAppButton).setOnClickListener { pickApp() }
        findViewById<Button>(R.id.runButton).setOnClickListener { runScript() }
        findViewById<Button>(R.id.stopButton).setOnClickListener {
            job?.cancel()
            appendLog("تم الإيقاف")
        }
    }

    override fun onResume() {
        super.onResume()
        val on = AutomationService.instance != null
        statusText.setText(if (on) R.string.status_on else R.string.status_off)
    }

    private fun runScript() {
        logText.text = ""
        job?.cancel()
        job = lifecycleScope.launch {
            ScriptRunner.run(scriptInput.text.toString()) { appendLog(it) }
        }
    }

    private fun appendLog(line: String) {
        logText.append(line + "\n")
    }

    /** يعرض التطبيقات المثبتة ويضيف أمر open للتطبيق المختار. */
    private fun pickApp() {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .sortedBy { it.first.lowercase() }

        AlertDialog.Builder(this)
            .setTitle(R.string.pick_app)
            .setItems(apps.map { "${it.first}\n${it.second}" }.toTypedArray()) { _, which ->
                val pkg = apps[which].second
                val current = scriptInput.text.toString()
                val prefix = if (current.isEmpty() || current.endsWith("\n")) "" else "\n"
                scriptInput.setText("$current${prefix}open $pkg\n")
                scriptInput.setSelection(scriptInput.text.length)
            }
            .show()
    }
}
