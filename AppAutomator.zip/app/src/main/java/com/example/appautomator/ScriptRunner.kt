package com.example.appautomator

import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlin.coroutines.coroutineContext

/**
 * ينفّذ سكربت بسيطًا سطرًا بسطر. الأوامر:
 *   open <package>   click <text>   type <text>   wait <ms>
 *   scroll down|up   tap <x> <y>    back | home | recents
 * الأسطر التي تبدأ بـ # تُتجاهل.
 */
object ScriptRunner {

    suspend fun run(script: String, log: (String) -> Unit) {
        val service = AutomationService.instance
        if (service == null) {
            log("✗ خدمة إمكانية الوصول غير مفعّلة")
            return
        }

        val lines = script.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
        for ((i, line) in lines.withIndex()) {
            coroutineContext.ensureActive()
            val cmd = line.substringBefore(' ').lowercase()
            val arg = line.substringAfter(' ', "").trim()

            val ok: Boolean = when (cmd) {
                "open" -> service.openApp(arg)
                "click" -> retry { service.clickByText(arg) }
                "type" -> retry { service.typeText(arg) }
                "wait" -> {
                    delay(arg.toLongOrNull() ?: 1000L); true
                }
                "scroll" -> service.scroll(down = !arg.equals("up", ignoreCase = true))
                "tap" -> {
                    val p = arg.split(" ").mapNotNull { it.toFloatOrNull() }
                    if (p.size == 2) service.tap(p[0], p[1]) else false
                }
                "back" -> service.back()
                "home" -> service.home()
                "recents" -> service.recents()
                else -> {
                    log("؟ أمر غير معروف: $line"); continue
                }
            }
            log("${if (ok) "✓" else "✗"} ${i + 1}. $line")
            if (!ok) {
                log("تم إيقاف السكربت عند الخطأ")
                return
            }
            // مهلة قصيرة ليستقر الواجهة بين الأوامر
            if (cmd != "wait") delay(800)
        }
        log("اكتمل السكربت")
    }

    /** يعيد المحاولة حتى ~5 ثوانٍ لأن الواجهة قد تحتاج وقتًا لتظهر. */
    private suspend fun retry(block: () -> Boolean): Boolean {
        repeat(10) {
            if (block()) return true
            delay(500)
        }
        return false
    }
}
